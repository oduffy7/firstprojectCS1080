Author: Orla Duffy 

Welcome to my Beginners Knitting Blog, it is a knitting blog where I also have links to things that would have been helpful when I began knitting. 